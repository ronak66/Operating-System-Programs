#!/bin/bash

if [ $1 == "1" ]; then
	ls
elif [ $1 == "2" ]; then
	pwd
elif [ $1 == "3" ]; then
	who
elif [ $1 == "4" ]; then
	exit
fi


