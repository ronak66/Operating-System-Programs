#!/bin/bash

find $@
