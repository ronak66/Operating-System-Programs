#!/bin/bash

mv $@ ~/.recyclebin
