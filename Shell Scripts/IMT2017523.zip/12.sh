#!/bin/bash

echo -n "search: "
read search
if [ $search == "NIT" ]; then
	echo IIT
elif [ $search == "NIT" ]; then
	echo NIT
else
	echo STDERR
fi


