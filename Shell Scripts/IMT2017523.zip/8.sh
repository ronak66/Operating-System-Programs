#!/bin/bash

echo -n "login name: "  
read login_name
last "$user_name"
