#!/bin/bash

echo -n "file system: "
read file_sys
df /dev/$file_sys


