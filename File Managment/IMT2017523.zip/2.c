#include<stdio.h>

int main(){
	while(1){
	}
	return 0;
}


/*
Do:
	ls /proc | grep < id >
*/
